# 🌐 Tarjimon Bot

Telegram uchun matn tarjima boti. `aiogram 3.x` va `deep-translator` (Google Translate) asosida yozilgan.

## 📁 Fayl tuzilmasi

```
tarjimon_bot/
├── main.py           — Handler'lar, tarjima logikasi, dispatcher
├── buttons.py         — ReplyKeyboard va InlineKeyboard tugmalari
├── database.py         — SQLite orqali foydalanuvchilar va sozlamalar
├── config.py           — BOT_TOKEN, ADMIN_ID, TRANSLATE_API_KEY
├── requirements.txt
└── locales/
    ├── uz.json
    ├── ru.json
    └── en.json
```

## ⚙️ O'rnatish

1. Kerakli kutubxonalarni o'rnating:

```bash
pip install -r requirements.txt
```

2. `config.py` faylini oching va quyidagilarni to'ldiring (yoki muhit o'zgaruvchilari orqali bering):

```bash
export BOT_TOKEN="123456:ABC-YourBotTokenHere"
export ADMIN_ID="123456789"
export ADMIN_USERNAME="your_admin_username"
```

- `BOT_TOKEN` — @BotFather dan olinadi.
- `ADMIN_ID` — sizning Telegram ID raqamingiz (masalan @userinfobot orqali bilib olasiz).
- `ADMIN_USERNAME` — `/help` komandasida ko'rsatiladigan username.

## ▶️ Ishga tushirish

```bash
python main.py
```

Bot ishga tushgach, birinchi marta ma'lumotlar bazasi (`tarjimon.db`) avtomatik yaratiladi.

## ✨ Funksiyalar

**Foydalanuvchi uchun:**
- **Matn tarjima** — matn yuborasiz, tilni tanlaysiz, natijani olasiz.
- **Tezkor tarjima** — asosiy til juftligini bir marta belgilaysiz, keyin har bir xabar avtomatik tarjima qilinadi.
- **Til juftligini o'zgartirish** — tarjima yo'nalishini istalgan vaqtda o'zgartirish.
- `/language` — bot interfeysi tilini (O'zbek / Русский / English) tanlash.

**Admin uchun (faqat `ADMIN_ID` ga mos foydalanuvchiga ko'rinadi):**
- **Statistika** — jami foydalanuvchilar soni va top-5 til juftligi.
- **Reklama yuborish** — barcha foydalanuvchilarga xabar yuborish (tasdiqlash/bekor qilish bilan).

## 📌 Komandalar

| Komanda | Tavsif |
|---|---|
| `/start` | Botni ishga tushiradi |
| `/tarjima` | Tarjima rejimini boshlaydi |
| `/til` | Til juftligini o'rnatadi |
| `/language` | Bot interfeysi tilini tanlaydi |
| `/help` | Admin bilan bog'lanish havolasini ko'rsatadi |

## ⚠️ Eslatma

- `deep-translator` kutubxonasi Google Translate'dan foydalanadi va odatda API key talab qilmaydi, lekin internet ulanishi kerak.
- Ko'p sonli foydalanuvchiga reklama yuborishda Telegram cheklovlariga (flood limit) rioya qilish uchun xabarlar orasida kichik pauza qo'yilgan.
- Ishlab chiqarish (production) muhitida `BOT_TOKEN` kabi maxfiy ma'lumotlarni kodga yozmasdan, muhit o'zgaruvchilari yoki `.env` fayl orqali berish tavsiya etiladi.
