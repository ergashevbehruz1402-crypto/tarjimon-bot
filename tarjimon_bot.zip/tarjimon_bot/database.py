# database.py
# Foydalanuvchilar va ularning til sozlamalarini SQLite bazasida saqlash uchun modul.

import sqlite3
from contextlib import closing

import config

DB_PATH = config.DB_PATH


def init_db() -> None:
    """Baza va jadvallarni yaratadi (agar mavjud bo'lmasa)."""
    with closing(sqlite3.connect(DB_PATH)) as conn:
        cur = conn.cursor()
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY,
                username TEXT,
                interface_lang TEXT DEFAULT 'uz',
                mode TEXT DEFAULT 'idle',
                default_from TEXT,
                default_to TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
            """
        )
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS translations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                from_lang TEXT,
                to_lang TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
            """
        )
        conn.commit()


def add_user(user_id: int, username: str) -> None:
    """Yangi foydalanuvchini qo'shadi yoki mavjudini yangilaydi."""
    with closing(sqlite3.connect(DB_PATH)) as conn:
        cur = conn.cursor()
        cur.execute("SELECT user_id FROM users WHERE user_id = ?", (user_id,))
        if cur.fetchone() is None:
            cur.execute(
                "INSERT INTO users (user_id, username) VALUES (?, ?)",
                (user_id, username or ""),
            )
        else:
            cur.execute(
                "UPDATE users SET username = ? WHERE user_id = ?",
                (username or "", user_id),
            )
        conn.commit()


def get_user(user_id: int):
    """Foydalanuvchi ma'lumotlarini qaytaradi (sqlite3.Row yoki None)."""
    with closing(sqlite3.connect(DB_PATH)) as conn:
        conn.row_factory = sqlite3.Row
        cur = conn.cursor()
        cur.execute("SELECT * FROM users WHERE user_id = ?", (user_id,))
        return cur.fetchone()


def set_interface_lang(user_id: int, lang: str) -> None:
    with closing(sqlite3.connect(DB_PATH)) as conn:
        cur = conn.cursor()
        cur.execute(
            "UPDATE users SET interface_lang = ? WHERE user_id = ?", (lang, user_id)
        )
        conn.commit()


def set_mode(user_id: int, mode: str) -> None:
    """mode: 'idle' yoki 'quick'"""
    with closing(sqlite3.connect(DB_PATH)) as conn:
        cur = conn.cursor()
        cur.execute("UPDATE users SET mode = ? WHERE user_id = ?", (mode, user_id))
        conn.commit()


def set_default_pair(user_id: int, from_lang: str, to_lang: str) -> None:
    """Tezkor tarjima uchun asosiy til juftligini o'rnatadi va rejimni 'quick' ga o'tkazadi."""
    with closing(sqlite3.connect(DB_PATH)) as conn:
        cur = conn.cursor()
        cur.execute(
            "UPDATE users SET default_from = ?, default_to = ?, mode = 'quick' WHERE user_id = ?",
            (from_lang, to_lang, user_id),
        )
        conn.commit()


def get_default_pair(user_id: int):
    """(from_lang, to_lang) yoki (None, None) qaytaradi."""
    user = get_user(user_id)
    if user and user["default_from"] and user["default_to"]:
        return user["default_from"], user["default_to"]
    return None, None


def log_translation(user_id: int, from_lang: str, to_lang: str) -> None:
    """Statistika uchun har bir tarjima amalini qayd qiladi."""
    with closing(sqlite3.connect(DB_PATH)) as conn:
        cur = conn.cursor()
        cur.execute(
            "INSERT INTO translations (user_id, from_lang, to_lang) VALUES (?, ?, ?)",
            (user_id, from_lang, to_lang),
        )
        conn.commit()


def get_total_users() -> int:
    with closing(sqlite3.connect(DB_PATH)) as conn:
        cur = conn.cursor()
        cur.execute("SELECT COUNT(*) FROM users")
        return cur.fetchone()[0]


def get_top_language_pairs(limit: int = 5):
    """Eng ko'p ishlatilgan til juftliklarini qaytaradi: [(from, to, count), ...]"""
    with closing(sqlite3.connect(DB_PATH)) as conn:
        cur = conn.cursor()
        cur.execute(
            """
            SELECT from_lang, to_lang, COUNT(*) as cnt
            FROM translations
            GROUP BY from_lang, to_lang
            ORDER BY cnt DESC
            LIMIT ?
            """,
            (limit,),
        )
        return cur.fetchall()


def get_all_user_ids():
    with closing(sqlite3.connect(DB_PATH)) as conn:
        cur = conn.cursor()
        cur.execute("SELECT user_id FROM users")
        return [row[0] for row in cur.fetchall()]
