# main.py
# Tarjimon Bot — asosiy fayl: handlerlar, tarjima logikasi, dispatcher.

import asyncio
import json
import logging
import os

from aiogram import Bot, Dispatcher, Router, F
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.filters import Command, CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import CallbackQuery, Message

from deep_translator import GoogleTranslator

import buttons
import config
import database as db

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
LOCALES_DIR = os.path.join(BASE_DIR, "locales")
DEFAULT_LOCALE = "uz"

_locales_cache: dict[str, dict] = {}

router = Router()


# ---------------------------------------------------------------------------
# Lokalizatsiya yordamchi funksiyalari
# ---------------------------------------------------------------------------
def load_locale(lang: str) -> dict:
    """locales/<lang>.json faylini o'qib, keshda saqlaydi."""
    if lang not in _locales_cache:
        path = os.path.join(LOCALES_DIR, f"{lang}.json")
        if not os.path.exists(path):
            path = os.path.join(LOCALES_DIR, f"{DEFAULT_LOCALE}.json")
        with open(path, "r", encoding="utf-8") as f:
            _locales_cache[lang] = json.load(f)
    return _locales_cache[lang]


def get_locale_for(user_id: int) -> dict:
    """Foydalanuvchi interfeys tiliga mos lokalizatsiya lug'atini qaytaradi."""
    user = db.get_user(user_id)
    lang = user["interface_lang"] if user else DEFAULT_LOCALE
    return load_locale(lang or DEFAULT_LOCALE)


def is_admin(user_id: int) -> bool:
    return user_id == config.ADMIN_ID


# ---------------------------------------------------------------------------
# FSM holatlari
# ---------------------------------------------------------------------------
class TranslateText(StatesGroup):
    waiting_text = State()


class QuickSetup(StatesGroup):
    from_lang = State()
    to_lang = State()


class ChangePair(StatesGroup):
    from_lang = State()
    to_lang = State()


class Broadcast(StatesGroup):
    waiting_message = State()


# ---------------------------------------------------------------------------
# Tarjima funksiyasi (deep-translator orqali)
# ---------------------------------------------------------------------------
def translate_text(text: str, source: str, target: str) -> str:
    """
    Matnni source tildan target tilga tarjima qiladi.
    Xatolik yuz bersa, Exception qayta ko'tariladi (chaqiruvchi joyda ushlanadi).
    """
    try:
        result = GoogleTranslator(source=source, target=target).translate(text)
        if not result:
            raise ValueError("Bo'sh tarjima natijasi qaytdi")
        return result
    except Exception as e:  # noqa: BLE001
        logger.error("Tarjima xatosi (%s -> %s): %s", source, target, e)
        raise


# ---------------------------------------------------------------------------
# /start
# ---------------------------------------------------------------------------
@router.message(CommandStart())
async def cmd_start(message: Message, state: FSMContext) -> None:
    await state.clear()
    db.add_user(message.from_user.id, message.from_user.username or "")
    locale = get_locale_for(message.from_user.id)
    await message.answer(
        locale["start_welcome"],
        reply_markup=buttons.main_menu_keyboard(locale, is_admin(message.from_user.id)),
    )


# ---------------------------------------------------------------------------
# /help — faqat admin havolasini ko'rsatadi
# ---------------------------------------------------------------------------
@router.message(Command("help"))
async def cmd_help(message: Message) -> None:
    locale = get_locale_for(message.from_user.id)
    await message.answer(locale["help_text"].format(admin=config.ADMIN_USERNAME))


# ---------------------------------------------------------------------------
# /language — bot interfeysi tilini o'rnatish
# ---------------------------------------------------------------------------
@router.message(Command("language"))
async def cmd_language(message: Message) -> None:
    locale = get_locale_for(message.from_user.id)
    await message.answer(
        locale["language_select_prompt"], reply_markup=buttons.interface_language_keyboard()
    )


@router.callback_query(F.data.startswith("setlang:"))
async def cb_set_language(callback: CallbackQuery, state: FSMContext) -> None:
    lang = callback.data.split(":", 1)[1]
    db.add_user(callback.from_user.id, callback.from_user.username or "")
    db.set_interface_lang(callback.from_user.id, lang)
    locale = load_locale(lang)
    await callback.message.edit_text(locale["language_changed"])
    await callback.message.answer(
        locale["start_welcome"],
        reply_markup=buttons.main_menu_keyboard(locale, is_admin(callback.from_user.id)),
    )
    await callback.answer()


# ---------------------------------------------------------------------------
# Matn tarjima: /tarjima komandasi va "Matn tarjima" tugmasi
# ---------------------------------------------------------------------------
async def _start_translate_text(message: Message, state: FSMContext) -> None:
    locale = get_locale_for(message.from_user.id)
    await state.set_state(TranslateText.waiting_text)
    await message.answer(locale["send_text_to_translate"])


@router.message(Command("tarjima"))
async def cmd_tarjima(message: Message, state: FSMContext) -> None:
    await _start_translate_text(message, state)


@router.message(
    F.text.in_(["Matn tarjima", "Перевод текста", "Text translation"])
)
async def btn_translate_text(message: Message, state: FSMContext) -> None:
    await _start_translate_text(message, state)


@router.message(TranslateText.waiting_text)
async def receive_text_for_translation(message: Message, state: FSMContext) -> None:
    await state.update_data(text=message.text)
    locale = get_locale_for(message.from_user.id)
    await message.answer(
        locale["choose_target_lang"], reply_markup=buttons.language_inline_keyboard("translate")
    )


@router.callback_query(F.data.startswith("translate:"))
async def cb_translate_language_chosen(callback: CallbackQuery, state: FSMContext) -> None:
    target_lang = callback.data.split(":", 1)[1]
    data = await state.get_data()
    text = data.get("text")
    locale = get_locale_for(callback.from_user.id)

    if not text:
        await callback.answer()
        return

    try:
        result = translate_text(text, "auto", target_lang)
        db.log_translation(callback.from_user.id, "auto", target_lang)
        await callback.message.edit_text(locale["translation_result"].format(result=result))
    except Exception:  # noqa: BLE001
        await callback.message.edit_text(locale["translation_error"])

    await state.clear()
    await callback.answer()


# ---------------------------------------------------------------------------
# Tezkor tarjima: "Tezkor tarjima" tugmasi
# ---------------------------------------------------------------------------
@router.message(
    F.text.in_(["Tezkor tarjima", "Быстрый перевод", "Quick translate"])
)
async def btn_quick_translate(message: Message, state: FSMContext) -> None:
    locale = get_locale_for(message.from_user.id)
    from_lang, to_lang = db.get_default_pair(message.from_user.id)

    if from_lang and to_lang:
        # Asosiy til juftligi allaqachon o'rnatilgan — shunchaki rejimni yoqamiz
        db.set_mode(message.from_user.id, "quick")
        await message.answer(
            locale["quick_mode_enabled"].format(from_lang=from_lang, to_lang=to_lang)
        )
    else:
        await state.set_state(QuickSetup.from_lang)
        await message.answer(
            locale["quick_setup_prompt_from"],
            reply_markup=buttons.language_inline_keyboard("qfrom"),
        )


@router.callback_query(QuickSetup.from_lang, F.data.startswith("qfrom:"))
async def cb_quick_from(callback: CallbackQuery, state: FSMContext) -> None:
    from_lang = callback.data.split(":", 1)[1]
    await state.update_data(from_lang=from_lang)
    await state.set_state(QuickSetup.to_lang)
    locale = get_locale_for(callback.from_user.id)
    await callback.message.edit_text(locale["quick_setup_prompt_to"])
    await callback.message.answer(
        locale["select_to_lang"], reply_markup=buttons.language_inline_keyboard("qto")
    )
    await callback.answer()


@router.callback_query(QuickSetup.to_lang, F.data.startswith("qto:"))
async def cb_quick_to(callback: CallbackQuery, state: FSMContext) -> None:
    to_lang = callback.data.split(":", 1)[1]
    data = await state.get_data()
    from_lang = data.get("from_lang")
    db.set_default_pair(callback.from_user.id, from_lang, to_lang)
    locale = get_locale_for(callback.from_user.id)
    await callback.message.edit_text(
        locale["quick_mode_enabled"].format(from_lang=from_lang, to_lang=to_lang)
    )
    await state.clear()
    await callback.answer()


# ---------------------------------------------------------------------------
# Til juftligini o'zgartirish: "Til juftligini o'zgartirish" tugmasi va /til
# ---------------------------------------------------------------------------
@router.message(
    F.text.in_(
        ["Til juftligini o'zgartirish", "Изменить языковую пару", "Change language pair"]
    )
)
async def btn_change_pair(message: Message, state: FSMContext) -> None:
    locale = get_locale_for(message.from_user.id)
    await state.set_state(ChangePair.from_lang)
    await message.answer(
        locale["change_pair_prompt_from"],
        reply_markup=buttons.language_inline_keyboard("cfrom"),
    )


@router.message(Command("til"))
async def cmd_til(message: Message, state: FSMContext) -> None:
    await btn_change_pair(message, state)


@router.callback_query(ChangePair.from_lang, F.data.startswith("cfrom:"))
async def cb_change_from(callback: CallbackQuery, state: FSMContext) -> None:
    from_lang = callback.data.split(":", 1)[1]
    await state.update_data(from_lang=from_lang)
    await state.set_state(ChangePair.to_lang)
    locale = get_locale_for(callback.from_user.id)
    await callback.message.edit_text(locale["change_pair_prompt_to"])
    await callback.message.answer(
        locale["select_to_lang"], reply_markup=buttons.language_inline_keyboard("cto")
    )
    await callback.answer()


@router.callback_query(ChangePair.to_lang, F.data.startswith("cto:"))
async def cb_change_to(callback: CallbackQuery, state: FSMContext) -> None:
    to_lang = callback.data.split(":", 1)[1]
    data = await state.get_data()
    from_lang = data.get("from_lang")
    db.set_default_pair(callback.from_user.id, from_lang, to_lang)
    locale = get_locale_for(callback.from_user.id)
    await callback.message.edit_text(
        locale["pair_changed"].format(from_lang=from_lang, to_lang=to_lang)
    )
    await state.clear()
    await callback.answer()


# ---------------------------------------------------------------------------
# ADMIN: Statistika
# ---------------------------------------------------------------------------
@router.message(F.text.in_(["Statistika", "Статистика", "Statistics"]))
async def btn_stats(message: Message) -> None:
    if not is_admin(message.from_user.id):
        return

    locale = get_locale_for(message.from_user.id)
    total = db.get_total_users()
    top_pairs = db.get_top_language_pairs(5)

    if top_pairs:
        pairs_text = "\n".join(
            f"{i + 1}. {p[0]} → {p[1]} ({p[2]} ta)" for i, p in enumerate(top_pairs)
        )
    else:
        pairs_text = locale["no_data"]

    await message.answer(locale["stats_text"].format(total=total, pairs=pairs_text))


# ---------------------------------------------------------------------------
# ADMIN: Reklama yuborish (Broadcast)
# ---------------------------------------------------------------------------
@router.message(F.text.in_(["Reklama yuborish", "Рассылка", "Broadcast"]))
async def btn_broadcast(message: Message, state: FSMContext) -> None:
    if not is_admin(message.from_user.id):
        return

    locale = get_locale_for(message.from_user.id)
    await state.set_state(Broadcast.waiting_message)
    await message.answer(locale["broadcast_prompt"])


@router.message(Broadcast.waiting_message)
async def receive_broadcast_message(message: Message, state: FSMContext) -> None:
    if not is_admin(message.from_user.id):
        await state.clear()
        return

    locale = get_locale_for(message.from_user.id)
    await state.update_data(broadcast_text=message.text)
    await message.answer(
        locale["broadcast_confirm"].format(text=message.text),
        reply_markup=buttons.confirm_keyboard(locale),
    )


@router.callback_query(F.data == "broadcast_confirm")
async def cb_broadcast_confirm(callback: CallbackQuery, state: FSMContext) -> None:
    if not is_admin(callback.from_user.id):
        await callback.answer()
        return

    data = await state.get_data()
    text = data.get("broadcast_text")
    locale = get_locale_for(callback.from_user.id)

    if not text:
        await callback.answer()
        return

    bot = callback.bot
    user_ids = db.get_all_user_ids()
    sent, failed = 0, 0

    for uid in user_ids:
        try:
            await bot.send_message(uid, text)
            sent += 1
        except Exception as e:  # noqa: BLE001
            logger.warning("Reklamani %s ga yuborib bo'lmadi: %s", uid, e)
            failed += 1
        await asyncio.sleep(0.05)  # Telegram rate-limit uchun kichik pauza

    await callback.message.edit_text(locale["broadcast_sent"].format(sent=sent, failed=failed))
    await state.clear()
    await callback.answer()


@router.callback_query(F.data == "broadcast_cancel")
async def cb_broadcast_cancel(callback: CallbackQuery, state: FSMContext) -> None:
    locale = get_locale_for(callback.from_user.id)
    await callback.message.edit_text(locale["broadcast_cancelled"])
    await state.clear()
    await callback.answer()


# ---------------------------------------------------------------------------
# Qolgan barcha matnlar: agar "Tezkor tarjima" rejimi yoqilgan bo'lsa — avtomatik
# tarjima qiladi, aks holda tugmalar bilan menyuni ko'rsatadi.
# Bu handler ENG OXIRIDA ro'yxatdan o'tkazilishi shart.
# ---------------------------------------------------------------------------
@router.message(F.text)
async def catch_all_text(message: Message, state: FSMContext) -> None:
    current_state = await state.get_state()
    if current_state is not None:
        # Boshqa bir holat (FSM state) faol — bu handlerga umuman yetib kelmasligi kerak,
        # lekin ehtiyot chorasi sifatida qoldiramiz.
        return

    db.add_user(message.from_user.id, message.from_user.username or "")
    user = db.get_user(message.from_user.id)
    locale = get_locale_for(message.from_user.id)

    if user and user["mode"] == "quick" and user["default_from"] and user["default_to"]:
        try:
            result = translate_text(message.text, user["default_from"], user["default_to"])
            db.log_translation(message.from_user.id, user["default_from"], user["default_to"])
            await message.answer(result)
        except Exception:  # noqa: BLE001
            await message.answer(locale["translation_error"])
    else:
        await message.answer(
            locale["unknown_command"],
            reply_markup=buttons.main_menu_keyboard(locale, is_admin(message.from_user.id)),
        )


# ---------------------------------------------------------------------------
# Botni ishga tushirish
# ---------------------------------------------------------------------------
async def main() -> None:
    db.init_db()

    bot = Bot(
        token=config.BOT_TOKEN,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML),
    )
    dp = Dispatcher(storage=MemoryStorage())
    dp.include_router(router)

    await bot.delete_webhook(drop_pending_updates=True)
    logger.info("Tarjimon bot ishga tushdi...")
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
