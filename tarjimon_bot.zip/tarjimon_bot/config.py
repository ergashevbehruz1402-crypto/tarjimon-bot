# config.py
# Botning asosiy sozlamalari shu yerda saqlanadi.
# Diqqat: haqiqiy tokenlarni kodga to'g'ridan-to'g'ri yozmaslik,
# .env fayl yoki muhit o'zgaruvchilari (environment variables) orqali olish tavsiya etiladi.

import os

# Telegram bot tokeni (@BotFather dan olinadi)
BOT_TOKEN = os.getenv("BOT_TOKEN", "PUT_YOUR_BOT_TOKEN_HERE")

# Admin foydalanuvchining Telegram ID raqami (masalan @userinfobot orqali aniqlanadi)
ADMIN_ID = int(os.getenv("ADMIN_ID", "123456789"))

# /help komandasi uchun admin username (@ belgisisiz)
ADMIN_USERNAME = os.getenv("ADMIN_USERNAME", "admin_username")

# deep-translator kutubxonasi Google Translate uchun API key talab qilmaydi,
# lekin agar boshqa (pullik) tarjima xizmatidan foydalanmoqchi bo'lsangiz shu yerga qo'shishingiz mumkin.
TRANSLATE_API_KEY = os.getenv("TRANSLATE_API_KEY", "")

# Ma'lumotlar bazasi fayli
DB_PATH = os.getenv("DB_PATH", "tarjimon.db")
