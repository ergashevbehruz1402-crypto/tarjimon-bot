# buttons.py
# ReplyKeyboard va InlineKeyboard tugmalari shu yerda tuziladi.

from aiogram.types import (
    ReplyKeyboardMarkup,
    KeyboardButton,
    InlineKeyboardMarkup,
    InlineKeyboardButton,
)

# Tarjima uchun qo'llab-quvvatlanadigan tillar ro'yxati (nom -> til kodi)
LANGUAGES = {
    "🇺🇿 O'zbek": "uz",
    "🇷🇺 Rus": "ru",
    "🇬🇧 Ingliz": "en",
    "🇹🇷 Turk": "tr",
    "🇸🇦 Arab": "ar",
    "🇩🇪 Nemis": "de",
    "🇫🇷 Fransuz": "fr",
    "🇪🇸 Ispan": "es",
    "🇨🇳 Xitoy": "zh-CN",
    "🇰🇷 Koreys": "ko",
    "🇯🇵 Yapon": "ja",
}


def main_menu_keyboard(locale: dict, is_admin: bool) -> ReplyKeyboardMarkup:
    """Foydalanuvchi (va agar admin bo'lsa, admin) uchun asosiy menyu."""
    keyboard = [
        [KeyboardButton(text=locale["btn_translate_text"])],
        [KeyboardButton(text=locale["btn_quick_translate"])],
        [KeyboardButton(text=locale["btn_change_pair"])],
    ]
    if is_admin:
        keyboard.append(
            [
                KeyboardButton(text=locale["btn_stats"]),
                KeyboardButton(text=locale["btn_broadcast"]),
            ]
        )
    return ReplyKeyboardMarkup(keyboard=keyboard, resize_keyboard=True)


def language_inline_keyboard(prefix: str) -> InlineKeyboardMarkup:
    """
    Til tanlash uchun inline klaviatura.
    prefix - callback_data ni turli holatlar (matn tarjima, tezkor tarjima,
    til juftligi o'zgartirish) uchun farqlash uchun ishlatiladi.
    """
    buttons = []
    row = []
    for i, (name, code) in enumerate(LANGUAGES.items(), start=1):
        row.append(InlineKeyboardButton(text=name, callback_data=f"{prefix}:{code}"))
        if i % 2 == 0:
            buttons.append(row)
            row = []
    if row:
        buttons.append(row)
    return InlineKeyboardMarkup(inline_keyboard=buttons)


def confirm_keyboard(locale: dict) -> InlineKeyboardMarkup:
    """Reklama yuborishni tasdiqlash/bekor qilish uchun inline klaviatura."""
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text=locale["confirm_yes"], callback_data="broadcast_confirm"
                ),
                InlineKeyboardButton(
                    text=locale["confirm_no"], callback_data="broadcast_cancel"
                ),
            ]
        ]
    )


def interface_language_keyboard() -> InlineKeyboardMarkup:
    """/language komandasi uchun bot interfeysi tilini tanlash klaviaturasi."""
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="🇺🇿 O'zbek", callback_data="setlang:uz")],
            [InlineKeyboardButton(text="🇷🇺 Русский", callback_data="setlang:ru")],
            [InlineKeyboardButton(text="🇬🇧 English", callback_data="setlang:en")],
        ]
    )
